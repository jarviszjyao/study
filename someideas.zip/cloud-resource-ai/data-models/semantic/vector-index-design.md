Index dimension: 768
Similarity: cosine
