Use sentence embeddings for entity names.
