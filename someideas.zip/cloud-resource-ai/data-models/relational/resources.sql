CREATE TABLE resources(
 id UUID,
 cloud VARCHAR,
 resource_type VARCHAR,
 department VARCHAR,
 project VARCHAR
);