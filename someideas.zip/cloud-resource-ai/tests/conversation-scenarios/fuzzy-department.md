Input:
"show retail resources"

Expected:
clarification required.
