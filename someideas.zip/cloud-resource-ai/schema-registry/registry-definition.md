Registry exposes datasets safely to LLM.
