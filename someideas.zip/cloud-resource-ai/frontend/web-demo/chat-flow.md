User sends message → loading → response render
