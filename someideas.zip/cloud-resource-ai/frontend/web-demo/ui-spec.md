Components:
- chat window
- message history
- chart panel