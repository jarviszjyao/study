Execution Rules:

- read-only queries
- enforced row filters
- max result size 5000 rows
- timeout 10s