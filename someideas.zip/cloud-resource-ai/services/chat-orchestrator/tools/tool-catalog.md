Available Tools:

- intent_classifier
- entity_resolver
- query_planner
- query_executor
- visualization_planner