Chat Orchestrator routes conversation flow.

Responsibilities:
- session management
- workflow routing
- skill invocation

Not responsible for:
- SQL generation
- business logic