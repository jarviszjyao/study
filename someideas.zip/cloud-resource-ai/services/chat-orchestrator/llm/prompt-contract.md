LLM must return JSON only.

No explanations allowed.

Failure → retry once.