# Orchestrator Flow

1. Receive user message
2. Retrieve session
3. Build reasoning context
4. Invoke LLM
5. Parse structured response
6. Decide next action

Possible actions:

- ask clarification
- resolve entity
- build query
- execute query