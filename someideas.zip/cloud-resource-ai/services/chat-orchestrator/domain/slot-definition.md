Slots:

department
cloud
resource_type
project
time_range