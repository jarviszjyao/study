Session contains:

- session_id
- conversation_history
- intent
- slots
- clarification_state
- query_spec