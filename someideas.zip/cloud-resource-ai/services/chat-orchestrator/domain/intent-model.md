Intent categories:

- list_resources
- aggregate_resources
- visualize_distribution
- unknown