DynamoDB PK = session_id
Attributes:
- state
- history
- ttl