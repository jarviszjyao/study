Session expires after 30 minutes idle.

Conversation summary retained separately.