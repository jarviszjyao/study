Input text
→ embedding search
→ alias match
→ ranking
→ candidate list