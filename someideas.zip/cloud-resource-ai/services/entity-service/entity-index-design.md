OpenSearch vector index:

fields:
- name
- aliases
- embedding