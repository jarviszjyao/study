Visualization output must include:

type
data
axes
title