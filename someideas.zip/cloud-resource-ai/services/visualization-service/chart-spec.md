Charts:

bar_chart
pie_chart
table
treemap