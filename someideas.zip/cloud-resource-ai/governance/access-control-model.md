RBAC based on department ownership.
