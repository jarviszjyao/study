Cache Query Specs to reduce LLM calls.
