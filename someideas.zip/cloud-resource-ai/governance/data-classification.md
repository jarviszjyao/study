Inventory metadata = Internal Confidential.
