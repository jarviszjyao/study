Log:
user_id
query_spec
execution_time
