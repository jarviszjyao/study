# Supported Use Cases

- List resources by department
- Aggregate database versions
- Show project distribution across clouds
- Identify ownership
- Visualize infrastructure topology

Future:
- troubleshooting
- remediation suggestions