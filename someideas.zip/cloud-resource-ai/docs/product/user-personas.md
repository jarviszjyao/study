# User Personas

## Cloud Engineer
Needs:
- fast resource lookup
- ownership discovery
- configuration inspection

## Dev Team Member
Needs:
- find project resources
- understand deployments

## Security / ITSO
Needs:
- compliance overview
- violation explanation

## Management
Needs:
- aggregated visualization
- resource distribution insights