# Tool / Skill Definition

| Skill               | Purpose               |
| ------------------- | --------------------- |
| Intent Skill        | classify user request |
| Entity Skill        | resolve fuzzy names   |
| Query Skill         | produce Query Spec    |
| Execution Skill     | retrieve data         |
| Visualization Skill | suggest chart         |

Input:
 structured JSON

Output:
 structured JSON

No natural language output.
