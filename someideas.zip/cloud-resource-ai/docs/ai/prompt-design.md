# Prompt Design Principles

Prompts must be:

1. Structured
2. Deterministic
3. Schema-aware
4. Role constrained

---

## Prompt Sections

SYSTEM ROLE
SCHEMA CONTEXT
SESSION CONTEXT
USER INPUT
OUTPUT FORMAT CONTRACT