# Chat Flow

1. User sends message
2. Session loaded
3. Intent skill invoked
4. Entity resolution if needed
5. Query spec generated
6. Query executed
7. Result formatted
8. Response returned