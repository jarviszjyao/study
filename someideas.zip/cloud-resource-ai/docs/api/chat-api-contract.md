POST /chat

Request:
{
  "session_id": "",
  "message": ""
}

Response:
{
  "reply": "",
  "visualization": {}
}