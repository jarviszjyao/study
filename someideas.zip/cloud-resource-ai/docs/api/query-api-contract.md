POST /query

Input:
Query Spec JSON

Output:
Dataset JSON