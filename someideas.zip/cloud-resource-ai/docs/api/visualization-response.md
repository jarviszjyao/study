{
  "type": "bar_chart",
  "x": "department",
  "y": "count",
  "data": []
}