# Graph Model

Nodes:
- Department
- Project
- Account
- Resource

Edges:
OWNS
DEPLOYED_IN
BELONGS_TO
