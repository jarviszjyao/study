# Entity Resolution

Handles fuzzy inputs.

Example:
"retail team"
→ Retail Banking Department

Methods:
1. vector similarity
2. alias mapping
3. graph lookup
