# Metadata Ingestion

Periodic scanners collect cloud metadata.

Sources:
- AWS APIs
- Azure Resource Graph
- GCP Asset Inventory
- Alibaba Cloud APIs

Stored into relational inventory database.

Frequency:
5–15 minutes.