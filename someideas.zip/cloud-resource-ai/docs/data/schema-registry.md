# Schema Registry

Central definition of datasets exposed to AI.

Purpose:
Prevent LLM hallucinated tables.

Registry contains:
- dataset name
- columns
- allowed filters