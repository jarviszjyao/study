# Project Phases

Phase 0 — Repo Bootstrap
Phase 1 — Session Infrastructure
Phase 2 — Chat Orchestrator Skeleton
Phase 3 — Intent Detection
Phase 4 — Clarification Loop
Phase 5 — Query Spec Generation
Phase 6 — Query Executor
Phase 7 — Frontend Integration
Phase 8 — Observability
Phase 9 — Production Hardening