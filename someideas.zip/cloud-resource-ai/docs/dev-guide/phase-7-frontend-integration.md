# Phase 7 — Frontend Integration

Goal:
UI chat communicates with backend.

Features:

- chat input box
- message history
- loading state
- chart rendering

API:

POST /chat

Definition of Done:

✓ Multi-turn chat works
✓ Charts render resource distribution