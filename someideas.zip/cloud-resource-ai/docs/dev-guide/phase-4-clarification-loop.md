# Phase 4 — Clarification Loop

Goal:
System asks follow-up questions.

Example:

User: show payment accounts

System detects multiple matches.

Orchestrator:
- queries department list
- asks user selection

Session stores:

clarification_state

Definition of Done:

✓ Multi-turn conversation works
✓ Next user message resolves ambiguity