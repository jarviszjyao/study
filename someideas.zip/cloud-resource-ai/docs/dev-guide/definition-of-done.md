# Global Definition of Done

System is complete when:

✓ User asks vague question
✓ System clarifies intent
✓ Query Spec generated
✓ Data retrieved securely
✓ Results visualized
✓ Session remembered
✓ Logs traceable