# Phase 0 — Repository Bootstrap

Goal:
Create project skeleton only.

Expected Output:

backend/
frontend/
docs/
schemas/
prompts/

No business logic yet.

Definition of Done:

✓ Repo builds
✓ Folder structure exists
✓ README explains system purpose