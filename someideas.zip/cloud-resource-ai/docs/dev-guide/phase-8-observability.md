# Phase 8 — Observability

Add:

- CloudWatch structured logs
- token usage logging
- intent accuracy metrics
- latency tracking

Definition of Done:

✓ Each request traceable
✓ LLM cost measurable